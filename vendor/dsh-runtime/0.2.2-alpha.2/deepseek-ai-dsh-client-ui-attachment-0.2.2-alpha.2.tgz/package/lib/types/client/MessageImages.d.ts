import type { FactoryComponentPropsOf, PropsRenderFactories } from '@deepseek-ai/dsh-client-ui-slots';
import type { MessageImagesOwnerProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
type MessageImagesProps = MessageImagesOwnerProps & PropsRenderFactories;
/**
 * Render a gallery with an authorized loader and caller-owned or default labels.
 * @param props - image sources, authorized loader, layout hints, optional labels, and Factory locale seat.
 * @returns the official gallery; no Session binding is needed by this component.
 */
export declare function MessageImagesContent({ images, loadImage, align, compact, thumbnail, labels, t, fileDrag }: FactoryComponentPropsOf<'conversation.images.content'>): import("react").JSX.Element;
/**
 * Fill a message, trajectory, or tool image position through the shared Content Factory.
 * @param props - Slot owner image data, authorized loader, and framework Factory renderer.
 * @returns the official gallery occurrence.
 */
export declare function MessageImages({ images, loadImage, align, compact, thumbnail, renderFactorySlot }: MessageImagesProps): import("react").ReactNode;
export {};
//# sourceMappingURL=MessageImages.d.ts.map