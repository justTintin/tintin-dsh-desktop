/**
 * The last known state of every change request that a listed Session binds,
 * for the Session list. One run starts with the first stream and stops with
 * the last: it reads the stored states, lists the Sessions with their
 * bindings, follows binding changes of loaded Sessions, and polls each bound
 * change request, once however many Sessions bind it. The forge service
 * owns polling cadence and terminal-state refresh. Every state change is stored, so a restart shows it before the
 * first poll.
 */
import { z } from 'zod';
import type { ChangeRequestListener, ChangeRequestRef } from '@deepseek-ai/dsh-experimental-forge/types';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { ForgeChangeRequestListState, ForgeChangeRequestStatesFrame } from './types.ts';
/** Stored states keyed by {@link storedKey}; derived data, so a record that fails its schema is set aside. */
export declare const changeRequestStatesDomain: {
    name: string;
    version: number;
    layout: "per-record";
    invalidRecords: "backup-and-skip";
    tables: {
        states: {
            valueSchema: z.ZodType<ForgeChangeRequestListState, unknown, z.core.$ZodTypeInternals<ForgeChangeRequestListState, unknown>>;
        };
    };
};
/**
 * The storage key of a change request's state: a path-safe digest of its URL.
 * @param url - the change request's web URL.
 * @returns the key.
 */
export declare function storedKey(url: string): string;
/** The stored states the run reads and writes. */
export interface StoredStates {
    /** The state stored under a key. */
    get(key: string): ForgeChangeRequestListState | undefined;
    /** Every stored state. */
    entries(): IterableIterator<[string, ForgeChangeRequestListState]>;
    /** Store a state durably. */
    put(key: string, value: ForgeChangeRequestListState): Promise<void>;
    /** Remove a stored state durably. */
    delete(key: string): Promise<boolean>;
}
/** One listed Session and the URLs of its visible bindings, undefined when they are not known without loading it. */
export interface ListedSession {
    readonly id: SessionId;
    readonly urls: readonly string[] | undefined;
}
/** What a run reads, follows, and polls. */
export interface ChangeRequestStateSources {
    /** List every Session with its visible bindings. */
    readonly sessions: (signal: AbortSignal) => Promise<readonly ListedSession[]>;
    /** Follow the visible bindings of loaded Sessions; returns the disposer. */
    readonly onBindings: (listener: (id: SessionId, urls: readonly string[]) => void) => () => void;
    /** The change request a URL names, or undefined when no provider recognizes it. */
    readonly refOf: (url: string) => ChangeRequestRef | undefined;
    /** Poll a change request until the returned disposer runs. */
    readonly watch: (ref: ChangeRequestRef, listener: ChangeRequestListener) => () => void;
    /** Open the stored states. */
    readonly open: () => Promise<StoredStates>;
    /** Report a failed durable write; the state stays in memory. */
    readonly report: (error: unknown) => void;
}
/** Streams the states of the change requests that listed Sessions bind. */
export declare class ChangeRequestStates {
    private readonly sources;
    private readonly readers;
    private stopping;
    private disposed;
    private run;
    /** @param sources - what runs read, follow, and poll. */
    constructor(sources: ChangeRequestStateSources);
    /**
     * Stream the known states the reader may see first, then each state that
     * changes or becomes visible to it. The stream ends when `signal` aborts or
     * the hub is disposed.
     * @param allowed - whether the reader may read a Session.
     * @param signal - ends the stream.
     * @returns frames in publication order.
     */
    stream(allowed: (id: SessionId) => boolean, signal: AbortSignal): AsyncIterable<ForgeChangeRequestStatesFrame>;
    /**
     * End every stream, stop polling, and wait for initialization and accepted storage writes.
     * @returns settles after all owned work stops; subsequent streams end without starting work.
     */
    dispose(): Promise<void>;
    private ensureRun;
    private stopRun;
}
//# sourceMappingURL=states.d.ts.map