/**
 * Body of the changes tab: the local changes of the Session's checkout in a
 * chosen scope, or the changes of one of its change requests, as one list of
 * file sections under a toolbar that jumps between files and switches the
 * layout. The view reads the changes when it opens, on each navigation, on
 * refresh, and when the change request's head or the checkout's `branch`
 * scope summary changes; a read keeps the previous changes on screen until it settles.
 */
import { type ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { ForgeChangeRequestDiff, ForgeLocalDiff, ForgeLocalScope } from '../types.ts';
import type { createChangesStore } from './changes-store.ts';
import type { ForgePanelKey, NS } from './locales.ts';
import type { PanelSnapshot } from './source.ts';
/** Business face of the changes tab body. */
export interface ChangesTabInjected {
    /** Panel source while visible; the renderer releases the subscription for an inactive key. */
    readonly keyedHooks: {
        readonly panel: (visibility: string) => HostObservable<PanelSnapshot> | undefined;
    };
    /** Open the panel stream again after it ended. */
    readonly reconnect: () => void;
    /** Read the local changes of one scope; `signal` aborts the read. */
    readonly localDiff: (scope: ForgeLocalScope, signal: AbortSignal) => Promise<RemoteResult<ForgeLocalDiff>>;
    /** Read the new side of one file in a local scope. */
    readonly localText: (scope: ForgeLocalScope, path: string) => Promise<RemoteResult<string>>;
    /** Read the changes of a change request by its binding URL; `signal` aborts the read. */
    readonly changeRequestDiff: (url: string, signal: AbortSignal) => Promise<RemoteResult<ForgeChangeRequestDiff>>;
    /** Read one file of a change request at a commit. */
    readonly changeRequestText: (url: string, commit: string, path: string) => Promise<RemoteResult<string>>;
    /** Open a URL outside the app. */
    readonly openLink: (url: string) => void;
    /** Copy a path to the clipboard and report the outcome. */
    readonly copyPath: (path: string) => void;
    /** Ask the Session's Agent to create a change request for its changes, reporting the outcome. */
    readonly createChangeRequest: () => void;
    /** Show a failure notice. */
    readonly report: (key: ForgePanelKey, params?: Readonly<Record<string, string>>) => void;
}
/** Full props of the changes tab body. */
export type ChangesTabProps = Pick<PropsRuntime<'sidebar.right.pane.tab'>, 'useTabInfo' | 'sessionId'> & PropsStore<ReturnType<typeof createChangesStore>> & InjectFace<ChangesTabInjected> & PropsLocale<typeof NS>;
/**
 * Render the changes tab of one Session.
 * @param props - tab information, the tab's choices, the panel snapshot hook, reads and actions, and copy.
 * @returns the view body.
 */
export declare function ChangesTab({ useTabInfo, sessionId, useStore, actions, usePanel, reconnect, localDiff, localText, changeRequestDiff, changeRequestText, openLink, copyPath, createChangeRequest, report, t, }: ChangesTabProps): ReactNode;
//# sourceMappingURL=ChangesTab.d.ts.map