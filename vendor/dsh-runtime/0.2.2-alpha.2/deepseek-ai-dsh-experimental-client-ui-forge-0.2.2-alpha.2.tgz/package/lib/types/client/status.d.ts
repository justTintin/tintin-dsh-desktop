/** Status derivations shared by the header entry, the change request cards, and the changes view. */
import type { ChangeRequestCheck, ChangeRequestSnapshot } from '@deepseek-ai/dsh-experimental-forge/types';
import type { ForgePanelChangeRequest, ForgePanelState } from '../types.ts';
import type { ForgePanelKey } from './locales.ts';
/**
 * Glyph tone of a change request: its lifecycle state, `blocked` for an open
 * one, not a draft, that needs its author, or `unknown` before the first snapshot.
 */
export type ChangeRequestTone = 'open' | 'blocked' | 'draft' | 'merged' | 'closed' | 'unknown';
/** Dictionary key of each tone's state name. */
export declare const TONE_LABEL: Record<ChangeRequestTone, ForgePanelKey>;
/** Combined check outcome shown on a collapsed card. */
export type CiSummary = {
    readonly kind: 'none';
} | {
    readonly kind: 'running';
} | {
    readonly kind: 'passed';
}
/** `count` is the number of failed checks the host listed, which can be zero when the list is truncated. */
 | {
    readonly kind: 'failed';
    readonly count: number;
};
/** Checks grouped by outcome; `other` holds neutral, skipped, and cancelled checks. */
export interface CheckCounts {
    readonly failed: number;
    readonly running: number;
    readonly passed: number;
    readonly other: number;
}
/** The most urgent fact of an open change request that the collapsed card names. */
export type ChangeRequestFlag = 'changesRequested' | 'conflicting' | 'draft';
/** The facts of a change request that decide its tone. */
export type ToneFacts = Pick<ChangeRequestSnapshot, 'state' | 'draft' | 'checksRollup' | 'reviewDecision' | 'mergeability'>;
/**
 * Pick the glyph tone of a change request: an open draft is always `draft`;
 * any other open one is `blocked` while its checks failed, changes were
 * requested, or it conflicts with its base, and running checks, a pending
 * review, and an unknown mergeability only wait and keep it `open`.
 * @param snapshot - latest snapshot or listed state, or null before the first one.
 * @returns the tone.
 */
export declare function toneOf(snapshot: ToneFacts | null): ChangeRequestTone;
/**
 * Count the listed checks by outcome.
 * @param checks - checks of the head commit.
 * @returns the counts.
 */
export declare function checkCounts(checks: readonly ChangeRequestCheck[]): CheckCounts;
/**
 * Summarize the checks of a change request from the host's combined outcome.
 * @param snapshot - change request status.
 * @returns the combined outcome with the failed count.
 */
export declare function ciSummary(snapshot: ChangeRequestSnapshot): CiSummary;
/**
 * Pick the flag a collapsed card names: requested changes before merge
 * conflicts before draft state; only open change requests carry one.
 * @param snapshot - change request status.
 * @returns the flag, or undefined when none applies.
 */
export declare function flagOf(snapshot: ChangeRequestSnapshot): ChangeRequestFlag | undefined;
/**
 * Whether a change request needs the user, the condition its card draws as `blocked`.
 * @param entry - bound change request.
 * @returns whether the header marks it.
 */
export declare function needsAttention(entry: ForgePanelChangeRequest): boolean;
/**
 * Pick the cards a Session's panel opens before the user expands or collapses
 * one: the only open change request, drafts included, when exactly one is open.
 * @param entries - bound change requests.
 * @returns the URLs of the cards that start expanded.
 */
export declare function defaultExpanded(entries: readonly ForgePanelChangeRequest[]): ReadonlySet<string>;
/**
 * Find the open change request, drafts included, whose head is the checked-out branch.
 * @param state - panel state of the Session.
 * @returns the change request, or undefined without one or while HEAD is detached.
 */
export declare function openChangeRequestOf(state: ForgePanelState): ForgePanelChangeRequest | undefined;
/**
 * Read the change request number: the provider's reference, else the number at the end of the URL path.
 * @param entry - bound change request.
 * @returns the number, or null when neither names one.
 */
export declare function numberOf(entry: Pick<ForgePanelChangeRequest, 'ref' | 'url'>): number | null;
/**
 * Measure how long a completed check ran.
 * @param check - one check.
 * @returns elapsed milliseconds, or undefined when either time is unknown or they are out of order.
 */
export declare function checkDuration(check: ChangeRequestCheck): number | undefined;
//# sourceMappingURL=status.d.ts.map