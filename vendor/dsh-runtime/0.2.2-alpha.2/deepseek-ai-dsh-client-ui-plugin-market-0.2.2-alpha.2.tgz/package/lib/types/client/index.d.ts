/**
 * Discover, browser half: the Plugins page tab that browses the plugin market indexes the user configures through the
 * `pluginMarket` Remote and installs an entry through the page's install dialog; entry pages show each version's
 * detail document.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type PluginMarketLocaleKey } from './locales.ts';
export type { DiscoverFace, DiscoverState } from './market-store.ts';
export type { PluginMarketLocaleKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Discover tab copy. */
        'pluginMarket': PluginMarketLocaleKey;
    }
}
/** Services the section reads. */
export declare const inject: string[];
/**
 * Contribute Discover to the Plugins page and keep it current on Host changes.
 * @param ctx - the browser plugin context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map