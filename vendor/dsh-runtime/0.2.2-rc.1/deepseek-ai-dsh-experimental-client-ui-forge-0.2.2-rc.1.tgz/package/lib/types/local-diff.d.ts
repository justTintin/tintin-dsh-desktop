/**
 * Local changes of a Session's checkout: where the `branch` scope forks, the
 * patch of one scope with its untracked files, the new-side text of one file,
 * and the size of the `branch` scope for the panel's card. Git runs through
 * the Session's Git runner; untracked and working-tree files are read through
 * `ctx.fs`, both within `maxDiffBytes`.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Session } from '@deepseek-ai/dsh-session';
import type { Git, GitConfig, Inspection } from './git.ts';
import type { ForgeLocalChanges, ForgeLocalDiff, ForgeLocalScope, ForgeSessionWorktree } from './types.ts';
/** Git limits plus the size limits of local diffs. */
export interface DiffConfig extends GitConfig {
    /** Largest patch, untracked file, or new-side file in bytes. */
    readonly maxDiffBytes: number;
    /** Most untracked files listed. */
    readonly maxUntrackedFiles: number;
}
/** The commit the `branch` scope compares with and the name the panel shows for it. */
export interface ForkPoint {
    /** Full commit object name. */
    readonly commit: string;
    /** Remote branch such as `origin/master`, the created worktree's base branch, or an abbreviated commit. */
    readonly label: string;
}
/** Thrown when a patch, a file list, or a file exceeds `maxDiffBytes`. */
export declare class DiffTooLarge extends Error {
    name: string;
}
/** Thrown when filter configuration cannot be read completely; no comparison has run. */
export declare class FilterConfigError extends Error {
    name: string;
}
/** Thrown for the `branch` scope of a checkout without a fork point. */
export declare class NoForkPoint extends Error {
    name: string;
}
/**
 * Find where the `branch` scope forks: the base commit of the worktree the
 * Session created while the checkout is that worktree, else the merge base of
 * HEAD with the default branch of the first remote that names one, in the
 * order the panel recognizes code hosts.
 * @param git - runner bound to the checkout.
 * @param inspection - the checkout and its remotes.
 * @param created - worktree the Session created, or null.
 * @returns the fork point, or null when no remote names a default branch or HEAD shares no history with it.
 */
export declare function forkPoint(git: Git, inspection: Inspection, created: ForgeSessionWorktree | null): Promise<ForkPoint | null>;
/**
 * Read changes at `root` with command-local clean/process filter overrides and without
 * submodule working-tree inspection. Git's built-in newline, ident, and encoding conversions still apply.
 * @param ctx - context that provides `fs`, `subprocess`, `sandbox`, and `sandboxPolicy`.
 * @param config - Git and size limits.
 * @param session - Session whose sandbox policy and execution world apply.
 * @param root - top-level directory of the checkout.
 * @param fork - fork point of the `branch` scope, or null without one.
 * @param scope - which changes to read.
 * @param signal - cancellation of every command and read.
 * @returns tracked files in Git's order, then untracked files unless the scope is `staged`.
 * @throws NoForkPoint for the `branch` scope without `fork`; FilterConfigError when filter configuration
 * cannot be read within `maxDiffBytes`; DiffTooLarge for oversized comparison output; an Error when Git fails.
 */
export declare function localDiff(ctx: Context, config: DiffConfig, session: Session, root: string, fork: ForkPoint | null, scope: ForgeLocalScope, signal: AbortSignal): Promise<ForgeLocalDiff>;
/**
 * Read the new side of one file in a scope, which supplies the unchanged
 * lines between hunks: the index for `staged`, else the working tree.
 * @param ctx - context that provides `fs`, `subprocess`, `sandbox`, and `sandboxPolicy`.
 * @param config - Git and size limits.
 * @param session - Session whose sandbox policy and execution world apply.
 * @param root - top-level directory of the checkout.
 * @param scope - the scope whose new side to read.
 * @param path - path relative to `root`, as the diff names it.
 * @param signal - cancellation.
 * @returns the text.
 * @throws DiffTooLarge over `maxDiffBytes`; an Error for a path outside the checkout, binary content, or a failed read.
 */
export declare function localText(ctx: Context, config: DiffConfig, session: Session, root: string, scope: ForgeLocalScope, path: string, signal: AbortSignal): Promise<string>;
/**
 * Measure the `branch` scope for the panel's card.
 * @param ctx - context that provides `fs`, `subprocess`, `sandbox`, and `sandboxPolicy`.
 * @param config - Git and size limits.
 * @param session - Session whose sandbox policy and execution world apply.
 * @param inspection - the checkout and its remotes.
 * @param created - worktree the Session created, or null.
 * @param signal - cancellation of every command and read.
 * @returns the base and the changed files, or null without a fork point.
 * @throws FilterConfigError when filter configuration cannot be read within `maxOutputBytes`;
 * DiffTooLarge when the untracked file list exceeds `maxDiffBytes`; an Error when Git fails.
 */
export declare function localChanges(ctx: Context, config: DiffConfig, session: Session, inspection: Inspection, created: ForgeSessionWorktree | null, signal: AbortSignal): Promise<ForgeLocalChanges | null>;
/**
 * Count the commits the checkout has beyond a change request's head, which a
 * change request diff does not show yet.
 * @param git - runner bound to the Session's directory.
 * @param branch - the change request's head branch.
 * @param commit - the change request's head commit.
 * @returns the count, or null on another branch, outside a checkout, or without the commit locally.
 */
export declare function aheadOf(git: Git, branch: string, commit: string): Promise<number | null>;
//# sourceMappingURL=local-diff.d.ts.map