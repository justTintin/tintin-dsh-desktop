/** Plain-text comment editor for a frozen selection in either review tab. */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ReviewQueue } from './review-queue.ts';
import type { ReviewSelection, ReviewSource } from './review.ts';
import type { NS } from './locales.ts';
/** Actions supplied by the owning changes tab. */
export interface ReviewActions {
    /** The source currently displayed; selecting a range freezes it. */
    readonly source: ReviewSource;
    /** Browser records shared by the changes tab. */
    readonly records?: ReviewQueue;
    /** Whether another comment already started a pending review. */
    readonly reviewStarted?: boolean;
    /** Open the confirmed publication URL. */
    readonly openLink?: (url: string) => void;
    /** A write is running or its outcome still needs confirmation. */
    readonly publishingBlocked?: boolean;
    /** Append an atomic quote without sending the Agent a message. */
    readonly addToInput: (selection: ReviewSelection) => boolean;
    /** Retain a new comment after its quote was accepted. */
    readonly onQuoted?: (selection: ReviewSelection) => void;
    /** Publish one comment; an error string preserves the editor. */
    readonly publish?: (selection: ReviewSelection) => Promise<string | undefined>;
    /** Keep one comment for the final review; false preserves the editor. */
    readonly queue?: (selection: ReviewSelection) => boolean;
}
/**
 * Render the line range, plain-text editor, and explicitly named destinations.
 * @param props - frozen selection, actions, cancellation, and localized copy.
 * @returns the inline comment form.
 */
export declare function ReviewComposer({ selection, actions, close, visible, split, t }: PropsLocale<typeof NS> & {
    readonly visible?: boolean;
    readonly split?: boolean;
    readonly selection: ReviewSelection;
    readonly actions: ReviewActions;
    readonly close: () => void;
}): ReactNode;
//# sourceMappingURL=ReviewComposer.d.ts.map