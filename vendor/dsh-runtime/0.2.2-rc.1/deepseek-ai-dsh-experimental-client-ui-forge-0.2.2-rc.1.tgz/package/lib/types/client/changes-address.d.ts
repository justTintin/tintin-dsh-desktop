/**
 * The changes view's tab type: the right-Sidebar view of one Session's local
 * changes or of one change request bound to it. Its addresses name the Session
 * and the source, `dsh-resource://forge-changes/<session>/local` or
 * `dsh-resource://forge-changes/<session>/change/<url>`, each part
 * percent-encoded; the source names the tab.
 */
import type { SidebarRightTabDefinition } from '@deepseek-ai/dsh-client-ui-sidebar-right/client';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { NS } from './locales.ts';
/** Kind of the changes tab. */
export declare const CHANGES_KIND = "forge-changes";
/** Registry id of the changes tab type, also the key its body and title register under. */
export declare const CHANGES_ID = "@deepseek-ai/dsh-experimental-client-ui-forge/changes";
/** What a changes view shows. */
export type ChangesSource = 
/** The changes of the Session's checkout. */
{
    readonly kind: 'local';
}
/** The changes of one change request bound to the Session, by its binding URL. */
 | {
    readonly kind: 'change';
    readonly url: string;
};
/** The Session and the source one address names. */
export interface ChangesTarget {
    /** Session whose checkout or binding the view reads. */
    readonly sessionId: SessionId;
    /** What the view shows. */
    readonly source: ChangesSource;
}
/** Navigation parameters of a changes tab. */
export interface ChangesParams {
    /** File to scroll to, by its path in the diff. */
    readonly path?: string;
}
declare module '@deepseek-ai/dsh-client-ui-sidebar-right/client' {
    interface SidebarRightResourceParamsMap {
        /** The file a changes tab scrolls to. */
        'forge-changes': ChangesParams;
    }
}
/**
 * Mint the address of a changes view.
 * @param target - Session and source.
 * @returns the `dsh-resource://forge-changes/…` address.
 */
export declare function changesAddress(target: ChangesTarget): string;
/**
 * Read the Session and source back out of a changes address.
 * @param address - a resource address.
 * @returns the target, or undefined for an address this package did not mint.
 */
export declare function parseChangesAddress(address: string): ChangesTarget | undefined;
/**
 * Name a changes view: 本地变更 for the local changes, #N 的变更 for a change request with a number.
 * @param source - what the view shows.
 * @param t - forge panel copy.
 * @returns the title in the current language.
 */
export declare function changesTitle(source: ChangesSource, t: TranslateNS<typeof NS>): string;
/**
 * The changes type's registry definition.
 * @param t - forge panel copy, read on every title call.
 * @returns the definition to register.
 */
export declare function changesDefinition(t: TranslateNS<typeof NS>): SidebarRightTabDefinition;
//# sourceMappingURL=changes-address.d.ts.map