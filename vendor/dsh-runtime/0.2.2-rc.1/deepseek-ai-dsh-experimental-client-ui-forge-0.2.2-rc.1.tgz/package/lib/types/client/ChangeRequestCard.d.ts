/**
 * One change request as a card: its title links to the host, a one-line
 * summary shows while collapsed, and while expanded one row per fact (checks,
 * review, merge state, and the changed lines, which open its changes) above
 * the ready-for-review or merge action.
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ChangeRequestSnapshot, MergeRequest } from '@deepseek-ai/dsh-experimental-forge/types';
import type { ForgePanelChangeRequest } from '../types.ts';
import type { NS } from './locales.ts';
type Translate = PropsLocale<typeof NS>['t'];
/** What a card can do; a surface without a Session binding omits `remove`, `markReady`, `merge`, and `viewChanges`. */
export interface ChangeRequestActions {
    /** Open a URL outside the app. */
    readonly openLink: (url: string) => void;
    /** Copy a URL to the clipboard. */
    readonly copyLink: (url: string) => void;
    /** Read the status again after a failed read. */
    readonly retry: () => void;
    /** Remove the change request from its Session. */
    readonly remove?: ((entry: ForgePanelChangeRequest) => void) | undefined;
    /** Mark a draft ready for review; settles once the outcome is reported. */
    readonly markReady?: ((entry: ForgePanelChangeRequest) => Promise<void>) | undefined;
    /** Merge the change request as `request` describes; settles once the outcome is reported. */
    readonly merge?: ((entry: ForgePanelChangeRequest, request: MergeRequest) => Promise<void>) | undefined;
    /** Load complete check details independently of polling; cancellation follows the open list. */
    readonly readChecks?: ((url: string, headSha: string, signal: AbortSignal) => Promise<ChangeRequestSnapshot>) | undefined;
    /** Open the changes view of the change request. */
    readonly viewChanges?: ((entry: ForgePanelChangeRequest) => void) | undefined;
}
/** Props of one change request card. */
export interface ChangeRequestCardProps {
    /** Change request with its latest snapshot and polling result. */
    readonly entry: ForgePanelChangeRequest;
    /** Whether the details show. */
    readonly expanded: boolean;
    /** Show or hide the details. */
    readonly onToggle: () => void;
    /** Current epoch milliseconds for relative times. */
    readonly now: number;
    /** Card actions. */
    readonly actions: ChangeRequestActions;
    /** Active UI language for numeric formatting. */
    readonly locale: string;
    /** Forge panel copy. */
    readonly t: Translate;
}
/**
 * Render one change request.
 * @param props - change request, expansion, current time, actions, and copy.
 * @returns the card.
 */
export declare function ChangeRequestCard({ entry, expanded, onToggle, now, actions, locale, t }: ChangeRequestCardProps): ReactNode;
export {};
//# sourceMappingURL=ChangeRequestCard.d.ts.map