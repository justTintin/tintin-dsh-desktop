import type { ProgramEvaluator } from './types.ts';
/**
 * Create a VM context supporting Script completion values and top-level await.
 * @returns Retained globals, asynchronous evaluation and resource cleanup.
 */
export declare function createVmScriptEvaluator(): ProgramEvaluator;
//# sourceMappingURL=vm-script.d.ts.map