/** Application consent checked before native observations and input. */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { z } from 'zod';
import { type NativeClient } from './native-client.ts';
import type { CuaAppHandle } from './types.ts';
import type { CuaApplicationGrant, CuaApplicationId } from './application-types.ts';
import type { CuaApplicationState } from './access-types.ts';
import { CuaPermissionStore } from './permission-store.ts';
/** Native identity admission occurs before any application observation or input. */
export declare const ApplicationAuthorizationResult: z.ZodObject<{
    id: z.ZodPipe<z.ZodString, z.ZodTransform<CuaApplicationId, string>>;
    name: z.ZodString;
    executablePath: z.ZodOptional<z.ZodString>;
    persistable: z.ZodBoolean;
}, z.core.$strip>;
/** Application consent uses one profile store, including conversation-scoped decisions. */
export interface AccessOptions {
    store: CuaPermissionStore;
}
/** Owns application consent and cancels operations when saved access is removed. */
export declare class ApplicationAccess {
    private readonly ctx;
    private readonly options;
    private readonly clients;
    private readonly active;
    private readonly selections;
    private readonly lifetime;
    private disposal;
    /** @param ctx Host context owning this provider. @param options Live saved grants and profile persistence. */
    constructor(ctx: Context, options: AccessOptions);
    /**
     * Cancel consent waits and join owned operations.
     * @returns Completion after consent waits and active operations settle.
     */
    dispose(): Promise<void>;
    /**
     * Project application decisions without requesting native permissions.
     * @returns Current saved grants and refused applications for the permission page.
     */
    status(): Promise<CuaApplicationState>;
    /**
     * Remove saved and session consent and join affected native operations.
     * @param id Application identity shown in the permission page.
     * @returns Completion after persistence and cancellation, including other processes' admitted operations.
     */
    revoke(id: CuaApplicationId): Promise<void>;
    /** Clear refusals without granting access or restoring old handles.
     * @param id Application selected by the human.
     * @returns Completion after the new asking policy is durable.
     */
    retryApproval(id: CuaApplicationId): Promise<void>;
    /**
     * Obtain consent for a freshly selected native handle. Free text never grants access.
     * @param agent Live agent whose session owns the decision.
     * @param client Helper that issued the handle.
     * @param handle Helper handle for a running instance or an approved pending launch.
     * @param identity Platform-provided application or process-instance identity.
     * @param signal Calling tool lifetime.
     * @param icon Native application icon for the permission card; never saved as an identity.
     * @returns Completion after consent; refusals reject before launch, AX, screenshots, or input.
     */
    select(agent: Agent, client: NativeClient, handle: CuaAppHandle, identity: CuaApplicationGrant & {
        persistable: boolean;
    }, signal: AbortSignal, icon?: string): Promise<void>;
    /**
     * Enforce live consent at the operation that dispatches native work.
     * @param client Helper owning the application handle.
     * @param handle Selected application.
     * @param signal Calling tool lifetime.
     * @param dispatch One native operation, with revocation cancellation.
     * @returns The native result, with no implicit retry after consent or cancellation.
     */
    run<T>(client: NativeClient, handle: CuaAppHandle, signal: AbortSignal, dispatch: (signal: AbortSignal) => Promise<T>): Promise<T>;
    private selectInOrder;
    private withOperation;
    /**
     * Release the disposed agent's handles while retaining its session decisions.
     * @param agent Disposed agent whose selected handles are released.
     */
    forget(agent: Agent): void;
    private permitted;
    private denied;
    private decide;
    private invalidate;
    private empty;
    private read;
    private save;
}
//# sourceMappingURL=application-access.d.ts.map