from __future__ import annotations

import os
import sys
from collections.abc import Mapping
from typing import Any

from jsonschema import Draft202012Validator

from connector.launch import launch_target
from connector.runtime_protocol import (
    AgentRuntime,
    RuntimeConfig,
    RuntimeConfigSchema,
    RuntimeInstancePolicy,
    RuntimeInvalidRequestError,
    RuntimeProvider,
    RuntimeTypeDescriptor,
    RuntimeUnavailableError,
)
from connector.runtime_protocol.host import RuntimeHostClient, runtime_kv_store
from connector.runtime_protocol.model_connection import (
    ModelConnectionCapability,
    ModelConnectionStatus,
    applied_status,
)
from connector.runtimes.claude import discovery, provider_config
from connector.runtimes.claude.runtime import ClaudeRuntime
from connector.runtimes.custom_models import normalize_custom_models
from connector.runtimes.model_gateway import model_gateway_from_config
from connector.runtimes.runtime_model import runtime_model_from_config

# Claude Code takes the connection as Anthropic environment variables in a
# settings file for every session process this instance starts.
MODEL_CONNECTION = ModelConnectionCapability(
    maturity="stable",
    protocols=("anthropic",),
    scope="instance",
    apply="restart",
    model_field="model",
)

CLAUDE_CONFIG_SCHEMA_REVISION = 5


class ClaudeProvider(RuntimeProvider):
    @property
    def runtime(self) -> str:
        return "claude"

    @property
    def runtime_type(self) -> str:
        return "claude"

    @property
    def display_name(self) -> str:
        return "Claude"

    @property
    def description(self) -> str:
        return "Anthropic Claude Agent SDK runtime"

    @property
    def instance_policy(self) -> RuntimeInstancePolicy:
        return "single"

    @property
    def max_instances(self) -> int:
        return 1

    def __init__(
        self,
        sdk_loader: discovery.SdkLoader | None = None,
        command_checker: discovery.CommandChecker | None = None,
    ) -> None:
        self._sdk_loader = sdk_loader or discovery.load_claude_sdk
        self._command_checker = command_checker or discovery.check_claude_target
        self._discovered_sdk: dict[str, Any] | None = None
        self._discovered_target = None

    async def discover(self) -> RuntimeTypeDescriptor:
        """Report the supported runtime type; SDK availability is a config/start check."""

        sdk = discovery.check_claude_sdk(self._sdk_loader)
        self._discovered_sdk = sdk
        environment = provider_config.merge_environment({})
        self._discovered_target = discovery.discover_claude_target(
            self._command_checker,
            environment,
        )
        return RuntimeTypeDescriptor(
            runtime_type=self.runtime_type,
            display_name=self.display_name,
            description=self.description,
            available=True,
            capabilities=provider_config.claude_capabilities(),
            reason=None,
            config_schema=await self.get_config_schema(),
            instance_policy=self.instance_policy,
            max_instances=self.max_instances,
            maturity="stable",
            model_connection=MODEL_CONNECTION,
            metadata={
                "configured": True,
                "sdk": sdk,
                "launchTarget": discovery.target_metadata(self._discovered_target),
                "platform": sys.platform,
            },
        )

    async def get_config_schema(self) -> RuntimeConfigSchema:
        schema = provider_config.claude_config_schema()
        return RuntimeConfigSchema(
            runtime=self.runtime,
            revision=CLAUDE_CONFIG_SCHEMA_REVISION,
            schema=schema,
            ui_schema={
                "order": [
                    "executablePath",
                    "modelGateway",
                    "environment",
                    "customModels",
                    "idleTimeoutSeconds",
                ],
                "modelGateway": {"component": "modelGateway"},
                "environment": {"component": "keyValue"},
                "customModels": {"component": "customModels"},
            },
            defaults={"environment": {}, "customModels": [], "idleTimeoutSeconds": 600},
        )

    async def validate_config(
        self,
        values: Mapping[str, Any],
    ) -> RuntimeConfig:
        raw_values = dict(values)
        model_gateway = model_gateway_from_config(raw_values.get("modelGateway"))
        if model_gateway is None:
            raw_values.pop("modelGateway", None)
        else:
            raw_values["modelGateway"] = model_gateway.to_config_values()
        schema = (await self.get_config_schema()).schema
        errors = sorted(
            Draft202012Validator(schema).iter_errors(raw_values),
            key=lambda error: list(error.absolute_path),
        )
        if errors:
            path = "/" + "/".join(str(part) for part in errors[0].absolute_path)
            raise RuntimeInvalidRequestError(
                f"claude config is invalid at {path or '/'}: {errors[0].message}"
            )

        environment = provider_config.merge_environment(raw_values.get("environment"))
        sdk = self._discovered_sdk or discovery.check_claude_sdk(self._sdk_loader)
        if not sdk.get("available"):
            raise RuntimeUnavailableError("Claude Agent SDK is not available")

        executable_path = raw_values.get("executablePath")
        launch_metadata = discovery.target_metadata(self._discovered_target)
        if isinstance(executable_path, str) and executable_path:
            target = launch_target(
                "configured",
                os.path.expandvars(os.path.expanduser(executable_path)),
            )
            result = self._command_checker(target, environment)
            if result.get("status") != "ok":
                raise RuntimeInvalidRequestError(
                    "Claude executable validation failed: "
                    f"{result.get('reason') or result.get('status')}"
                )
            launch_metadata = discovery.target_metadata(target)

        normalized_values: dict[str, Any] = {
            "environment": dict(raw_values.get("environment") or {}),
            "customModels": normalize_custom_models(raw_values.get("customModels")),
            "idleTimeoutSeconds": raw_values.get("idleTimeoutSeconds", 600),
        }
        if model_gateway is not None:
            normalized_values["modelGateway"] = model_gateway.to_config_values()
        if (model := runtime_model_from_config(normalized_values | {"model": raw_values.get("model")})) is not None:
            normalized_values["model"] = model.to_config_values()
        if isinstance(executable_path, str) and executable_path:
            normalized_values["executablePath"] = executable_path

        config_schema = await self.get_config_schema()
        return RuntimeConfig(
            runtime=self.runtime,
            revision=CLAUDE_CONFIG_SCHEMA_REVISION,
            values=normalized_values,
            schema=schema,
            ui_schema=config_schema.ui_schema,
            metadata={
                "sdk": sdk,
                "launchTarget": launch_metadata,
                "platform": sys.platform,
            },
        )

    @property
    def model_connection(self) -> ModelConnectionCapability:
        return MODEL_CONNECTION

    def model_connection_status(self, config: RuntimeConfig) -> ModelConnectionStatus:
        return applied_status(MODEL_CONNECTION, config.values)

    async def create_runtime(
        self,
        config: RuntimeConfig,
        host: RuntimeHostClient,
    ) -> AgentRuntime:
        sdk = config.metadata.get("sdk") if isinstance(config.metadata, dict) else None
        if isinstance(sdk, dict) and not sdk.get("available", True):
            raise RuntimeInvalidRequestError("Claude Agent SDK is not available")
        runtime = ClaudeRuntime(
            config=config,
            host=host,
            sdk_loader=self._sdk_loader,
            client_message_kv=runtime_kv_store(host),
        )
        from connector.planning.infrastructure.binding import bind_planning
        from connector.runtimes.claude.planning import ClaudePlanningPort

        bind_planning(runtime, host, ClaudePlanningPort(runtime))
        from connector.goals.binding import bind_goals
        from connector.runtimes.claude.goals import ClaudeGoalPort

        return bind_goals(runtime, host, ClaudeGoalPort(runtime))
