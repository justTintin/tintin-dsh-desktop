from __future__ import annotations

import asyncio
import json
import random
from collections.abc import Callable, Mapping
from contextlib import suppress
from pathlib import Path
from typing import Any

import httpx
import websockets
from websockets.exceptions import ConnectionClosed

from connector.core.config import ConnectorConfig
from connector.core.preferences import read_local_preferences
from connector.local import create_local_ops
from connector.logging import logger
from connector.runtime_protocol import (
    RuntimeHostClient,
)
from connector.runtime_protocol import (
    RuntimeProvider as AgentRuntimeProvider,
)
from connector.runtime_protocol import (
    RuntimeSupervisor as AgentRuntimeSupervisor,
)
from connector.runtime_protocol.host import UploadProgress
from connector.runtime_protocol.switch_fence import (
    RuntimeSwitchFenceStore,
    safe_file_stem,
)
from connector.runtimes import default_runtime_providers
from connector.server.auth import ConnectorAuthenticationError, ConnectorAuthenticator
from connector.server.capabilities import protocol_capabilities_from_runtime_types
from connector.server.dispatch import (
    ConnectorRequestDispatcher,
    ConnectorRequestSession,
    DeviceSettingsSink,
)
from connector.server.errors import ConnectorNetworkError
from connector.server.ingest import ConnectorIngestClient
from connector.server.network import NetworkEgress, certificate_hint
from connector.server.notification_coalescer import (
    TimelineItemNotificationCoalescer,
)
from connector.server.protocol_revision import ProtocolRevisionClock
from connector.server.rpc import ConnectorRpcChannel, ConnectorWebSocketFrameTooLarge
from connector.server.runtime_host import ConnectorRuntimeHost
from connector.server.runtime_rpc_payloads import (
    DeferredServerPayload,
    model_connection_result,
    server_payload_without_turn_data,
)
from connector.server.runtime_sync import RuntimeSyncRunner
from connector.server.sync_state import JsonSyncStateStore, SyncStateStore
from connector.server.terminal_relay import TerminalRelayRunner
from connector.server.transfers import (
    download_attachment as download_backend_attachment,
)
from connector.server.transfers import (
    upload_prepared_download as upload_backend_prepared_download,
)
from connector.server.urls import api_v2_path, device_os
from connector.server.urls import (
    ws_url as build_ws_url,
)

INGEST_ONLY_NOTIFICATION_METHODS = frozenset({"timeline.sync"})
SYNC_STATE_FLUSH_INTERVAL_SECONDS = 1.0


class BackendRpcClient:
    def __init__(
        self,
        config: ConnectorConfig,
        *,
        agent_runtime_providers: tuple[AgentRuntimeProvider, ...] | None = None,
        agent_runtime_host: RuntimeHostClient | None = None,
        preferences_reader: Callable[[], dict[str, Any]] | None = None,
        sync_state_store: SyncStateStore | None = None,
        device_settings_sink: DeviceSettingsSink | None = None,
    ) -> None:
        self.config = config
        self.sync_state_store = sync_state_store
        if self.sync_state_store is None:
            self.sync_state_store = JsonSyncStateStore(
                config.state_path or JsonSyncStateStore.default_path()
            )
        self.agent_runtime_host = agent_runtime_host or ConnectorRuntimeHost(
            connector_id=config.connector_id,
            notifier=self.send_backend_notification,
            attachment_downloader=self.download_attachment,
            sync_state_store=self.sync_state_store,
            ingest_notifications=self.ingest_notifications,
            ingest_snapshot=self.ingest_snapshot,
            defer_payload_projection=True,
        )
        if agent_runtime_providers is None:
            agent_runtime_providers = default_runtime_providers()
        self.agent_runtime_supervisor = AgentRuntimeSupervisor(
            providers=agent_runtime_providers,
            host=self.agent_runtime_host,
            status_sink=self._publish_agent_runtime_status,
            switch_fence=RuntimeSwitchFenceStore(
                lambda: runtime_switch_directory(config)
            ),
        )
        self._preferences_reader = preferences_reader or read_local_preferences
        self.local_ops = create_local_ops(notify=self.send_backend_notification)
        self._egress = NetworkEgress(config.server_url, config.proxy)
        self._terminal_relay = TerminalRelayRunner(config.server_url, self.local_ops, egress=self._egress)
        self._terminal_relay_lock = asyncio.Lock()
        self._terminal_relay_tasks: dict[str, tuple[str, asyncio.Task[None]]] = {}
        self._background_tasks: set[asyncio.Task[Any]] = set()
        self._rpc = ConnectorRpcChannel()
        self._protocol_revision_clock = ProtocolRevisionClock()
        # Persistent HTTP client: a long-lived connection pool eliminates the
        # 5–10ms TCP/TLS setup that the old `async with AsyncClient(...)`
        # per-call pattern paid on every notification.
        self._http_client: httpx.AsyncClient | None = None
        self._auth = ConnectorAuthenticator(
            config=config,
            http_client_getter=self._get_http_client,
            http_client_factory=lambda timeout: self._new_http_client(timeout=timeout),
        )
        self._ingest = ConnectorIngestClient(
            server_url=config.server_url,
            access_token_provider=self._auth.ensure_access_token,
            http_client_getter=self._get_http_client,
            http_client_factory=lambda timeout: self._new_http_client(timeout=timeout),
        )
        self._timeline_notifications = TimelineItemNotificationCoalescer(
            self._send_backend_notification_now
        )
        self._dispatcher = ConnectorRequestDispatcher(
            agent_runtime_supervisor=self.agent_runtime_supervisor,
            agent_runtime_host=self.agent_runtime_host,
            local_ops=self.local_ops,
            upload_prepared_download=self.upload_prepared_download,
            start_terminal_relay=self.start_terminal_relay,
            schedule_background=self._schedule_background,
            device_settings_sink=device_settings_sink,
        )
        self._runtime_sync = RuntimeSyncRunner(
            config=config,
            supervisor=self.agent_runtime_supervisor,
            host=self.agent_runtime_host,
            preferences_reader=self._preferences_reader,
            send_notification=self.send_backend_notification,
            ingest_notifications=self.ingest_notifications,
            flush_sync_state=self._flush_sync_state,
            ingest_snapshot=self.ingest_snapshot,
        )
        self._runtime_sync_task: asyncio.Task[None] | None = None

    def _reconnect_delay(self) -> float:
        """Stop connectors dropped together from reconnecting in lockstep."""
        return self.config.reconnect_seconds * random.uniform(1, 2)

    async def run_forever(self) -> None:
        await self._egress.refresh()
        self._http_client = self._new_http_client(timeout=60)
        ingest_flush_task = asyncio.create_task(self._ingest.flush_loop())
        sync_state_flush_task = asyncio.create_task(self._sync_state_flush_loop())
        try:
            while True:
                try:
                    connection_task = asyncio.create_task(self.run_once())
                    try:
                        done, _ = await asyncio.wait(
                            {connection_task, ingest_flush_task},
                            return_when=asyncio.FIRST_COMPLETED,
                        )
                        if ingest_flush_task in done:
                            await ingest_flush_task
                            raise RuntimeError("connector ingest worker stopped")
                        await connection_task
                    finally:
                        connection_task.cancel()
                        await asyncio.gather(connection_task, return_exceptions=True)
                except asyncio.CancelledError:
                    raise
                except ConnectorAuthenticationError as exc:
                    logger.error("connector authentication failed; stopping: {}", exc)
                    raise
                except ConnectionClosed as exc:
                    close_code = _close_code(exc)
                    close_reason = _close_reason(exc)
                    if _is_auth_close(exc):
                        logger.error(
                            "backend websocket closed due to invalid connector credentials code={} reason={!r}; stopping",
                            close_code,
                            close_reason,
                        )
                        raise ConnectorAuthenticationError(
                            "connector credential no longer valid"
                        )
                    logger.warning(
                        "backend websocket closed code={} reason={!r}; reconnecting in at least {}s",
                        close_code,
                        close_reason,
                        self.config.reconnect_seconds,
                    )
                    await asyncio.sleep(self._reconnect_delay())
                except ConnectorNetworkError as exc:
                    logger.warning(
                        "connector backend network unavailable error={}; reconnecting in at least {}s",
                        exc,
                        self.config.reconnect_seconds,
                    )
                    await asyncio.sleep(self._reconnect_delay())
                except OSError as exc:
                    logger.warning(
                        "connector backend connection failed error={}; reconnecting in at least {}s",
                        certificate_hint(exc, self.config.server_url) or exc,
                        self.config.reconnect_seconds,
                    )
                    await asyncio.sleep(self._reconnect_delay())
                except Exception:
                    if ingest_flush_task.done():
                        raise
                    logger.exception(
                        "connector loop failed; reconnecting in at least {}s",
                        self.config.reconnect_seconds,
                    )
                    await asyncio.sleep(self._reconnect_delay())
        finally:
            relay_tasks = [task for _, task in self._terminal_relay_tasks.values()]
            for task in relay_tasks:
                task.cancel()
            await asyncio.gather(*relay_tasks, return_exceptions=True)
            if self._runtime_sync_task is not None:
                self._runtime_sync_task.cancel()
            try:
                async with asyncio.timeout(2):
                    await self._timeline_notifications.close()
                    await self._ingest.post_batch([])
            except Exception as exc:  # noqa: BLE001 - shutdown is bounded even when offline
                logger.warning("connector final notification flush incomplete error={}", exc)
            finally:
                self._ingest.close()
                await self._timeline_notifications.abort()
            ingest_flush_task.cancel()
            sync_state_flush_task.cancel()
            if self._runtime_sync_task is not None:
                self._runtime_sync_task.cancel()
            try:
                await ingest_flush_task
            except (asyncio.CancelledError, Exception):
                pass
            with suppress(asyncio.CancelledError):
                await sync_state_flush_task
            if self._runtime_sync_task is not None:
                try:
                    await self._runtime_sync_task
                except (asyncio.CancelledError, Exception):
                    pass
                self._runtime_sync_task = None
            try:
                await self._flush_sync_state()
            except Exception:  # noqa: BLE001
                logger.exception("final sync state flush failed")
            if self._http_client is not None:
                await self._http_client.aclose()
                self._http_client = None

    async def run_once(self) -> None:
        # A proxy changed in the system settings applies from this connection on.
        await self._egress.refresh()
        access_token = await self.ensure_access_token(force=True)
        websocket_url = build_ws_url(
            self.config.server_url, api_v2_path("/connector/ws")
        )
        logger.info("connecting backend websocket {}", websocket_url)
        request_session = self._dispatcher.new_session()
        async with websockets.connect(
            websocket_url,
            additional_headers={
                "Authorization": f"Bearer {access_token}",
                "X-Device-OS": device_os(),
            },
            **self._egress.websocket_options(websocket_url),
        ) as ws:
            self._rpc.set_connection(ws)
            capabilities_task = asyncio.create_task(
                self._publish_runtime_capabilities(request_session)
            )
            heartbeat_task = asyncio.create_task(self._heartbeat_loop())
            recovery_task = asyncio.create_task(self._runtime_sync.reconnect_event_runtimes())
            reader_task = asyncio.create_task(self._read_backend_messages(ws, request_session))
            try:
                if self._runtime_sync_task is None or self._runtime_sync_task.done():
                    self._runtime_sync_task = asyncio.create_task(
                        self._runtime_sync.sync_existing_loop()
                    )
                logger.info(
                    "connector startup complete; runtime sync started in background"
                )
                done, _ = await asyncio.wait({reader_task, heartbeat_task}, return_when=asyncio.FIRST_COMPLETED)
                if reader_task in done:
                    await reader_task
                else:
                    await heartbeat_task
                    raise ConnectorNetworkError("backend heartbeat stopped")
            finally:
                capabilities_task.cancel()
                heartbeat_task.cancel()
                recovery_task.cancel()
                reader_task.cancel()
                await asyncio.gather(
                    capabilities_task, heartbeat_task, recovery_task, reader_task, return_exceptions=True
                )
                await self._rpc.close_connection()

    async def _read_backend_messages(self, ws, request_session) -> None:
        async for raw_message in ws:
            self.start_message(json.loads(raw_message), request_session=request_session)

    async def _publish_runtime_capabilities(
        self, request_session: ConnectorRequestSession
    ) -> None:
        try:
            discovery = await request_session.discover_runtimes()
            await self.send_notification(
                "protocol.capabilitiesUpdated",
                protocol_capabilities_from_runtime_types(
                    discovery, revision=self._protocol_revision_clock.next()
                ),
            )
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception(
                "runtime capability discovery failed; connector RPC remains available"
            )

    async def authenticate(self) -> str:
        return await self._auth.authenticate()

    async def ensure_access_token(self, *, force: bool = False) -> str:
        return await self._auth.ensure_access_token(force)

    async def handle_message(
        self,
        message: dict[str, Any],
        request_session: ConnectorRequestSession | None = None,
    ) -> None:
        dispatcher = request_session or self._dispatcher
        await self._rpc.handle_message(message, dispatcher.dispatch)

    def start_message(
        self,
        message: dict[str, Any],
        request_session: ConnectorRequestSession | None = None,
    ) -> None:
        dispatcher = request_session or self._dispatcher
        self._rpc.start_request(message, dispatcher.dispatch)

    async def dispatch(self, method: str, params: dict[str, Any]) -> Any:
        return await self._dispatcher.dispatch(method, params)

    async def send_notification(self, method: str, params: dict[str, Any]) -> None:
        await self._rpc.send_notification(method, params)

    async def send_backend_notification(
        self, method: str, params: dict[str, Any]
    ) -> None:
        await self._timeline_notifications.send(method, params)

    async def _send_backend_notification_now(
        self, method: str, params: dict[str, Any]
    ) -> None:
        # Project only snapshots that survive coalescing. Doing this in the
        # Host recursively copied every intermediate message's entire body.
        if isinstance(params, DeferredServerPayload):
            params = server_payload_without_turn_data(params)
        if notification_requires_ingest(method):
            await self._ingest.enqueue(method, params)
            return
        if self._rpc.connected and not self._ingest.has_pending:
            try:
                await self.send_notification(method, params)
                return
            except (
                RuntimeError,
                ConnectionError,
                ConnectionClosed,
                ConnectorWebSocketFrameTooLarge,
            ) as exc:
                logger.warning(
                    "backend websocket notification failed; falling back to ingest method={} error={}",
                    method,
                    exc,
                )
        await self._ingest.enqueue(method, params)

    async def send_response(
        self,
        request_id: str,
        *,
        ok: bool,
        result: Any = None,
        error: dict[str, str] | None = None,
    ) -> None:
        await self._rpc.send_response(request_id, ok=ok, result=result, error=error)

    async def _heartbeat_loop(self) -> None:
        while True:
            await self.send_notification("connector.heartbeat", {})
            await asyncio.sleep(self.config.heartbeat_seconds)

    async def _sync_state_flush_loop(self) -> None:
        while True:
            await asyncio.sleep(SYNC_STATE_FLUSH_INTERVAL_SECONDS)
            try:
                await self._flush_sync_state()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                logger.exception("periodic sync state flush failed")

    async def _flush_sync_state(self) -> bool:
        store = self.sync_state_store
        if store is None:
            return False
        flushed = await asyncio.to_thread(store.flush)
        flush_runtime_storage = getattr(self.agent_runtime_host, "flush_runtime_storage", None)
        if callable(flush_runtime_storage):
            flushed = await asyncio.to_thread(flush_runtime_storage) or flushed
        if flushed:
            logger.debug("sync state changes flushed")
        return flushed

    async def _publish_runtime_status(
        self,
        runtime_type: str,
        runtime_id: str,
        status: str,
        error: Mapping[str, Any] | None,
        phase: Mapping[str, Any] | None = None,
        model_connection: Mapping[str, Any] | None = None,
        config_digest: str | None = None,
    ) -> None:
        payload: dict[str, Any] = {
            "runtime": runtime_type,
            "runtimeId": runtime_id,
            "status": status,
        }
        if error is not None:
            payload["error"] = error
        if phase is not None:
            payload["phase"] = phase
        if model_connection is not None:
            # Adapters that apply the connection after start (DSH) report it here.
            payload["modelConnection"] = model_connection
        if config_digest is not None:
            # Matches the switch the Server verifies against the loaded config.
            payload["configDigest"] = config_digest
        await self.send_notification("runtime.statusChanged", payload)

    async def _publish_agent_runtime_status(
        self,
        runtime_id: str,
        status: str,
        error: Mapping[str, Any] | None,
        phase: Mapping[str, Any] | None = None,
    ) -> None:
        entry = self.agent_runtime_supervisor.entry(runtime_id)
        await self._publish_runtime_status(
            entry.runtime_type,
            runtime_id,
            status,
            error,
            phase,
            model_connection_result(entry).get("modelConnection"),
            self.agent_runtime_supervisor.config_digest(runtime_id),
        )

    async def ingest_snapshot(self, *args, **kwargs) -> None:
        await self._ingest.ingest_snapshot(*args, **kwargs)

    async def ingest_notifications(self, notifications: list[dict[str, Any]], *, on_progress: UploadProgress | None = None) -> None:
        kwargs = {"on_progress": on_progress} if on_progress is not None else {}
        await self._ingest.ingest_notifications(notifications, **kwargs)

    async def download_attachment(
        self, session_id: str, file_id: str
    ) -> tuple[bytes, str, str]:
        return await download_backend_attachment(
            server_url=self.config.server_url,
            session_id=session_id,
            file_id=file_id,
            access_token_provider=self.ensure_access_token,
            http_client_factory=self._new_http_client,
        )

    async def upload_prepared_download(self, params: dict[str, Any]) -> dict[str, Any]:
        return await upload_backend_prepared_download(
            server_url=self.config.server_url,
            prepared_path=self.local_ops.prepared_download_path(params),
            params=params,
            access_token_provider=self.ensure_access_token,
            http_client_factory=self._new_http_client,
        )

    async def start_terminal_relay(self, params: dict[str, Any]) -> dict[str, Any]:
        terminal_id = params.get("terminalId")
        token = params.get("token")
        if not isinstance(terminal_id, str) or not terminal_id:
            raise ValueError("terminalId is required")
        if not isinstance(token, str) or not token:
            raise ValueError("token is required")
        async with self._terminal_relay_lock:
            attach = params.get("mode") == "attach"
            if attach:
                self.local_ops.terminal.prepare_relay(params)
            previous = self._terminal_relay_tasks.get(terminal_id)
            if previous is not None:
                old_token, old_task = previous
                if old_token == token and not old_task.done():
                    return {"terminalId": terminal_id, "connecting": True}
                old_task.cancel()
                await asyncio.gather(old_task, return_exceptions=True)
            task = asyncio.create_task(
                self._run_terminal_relay(terminal_id, token, attach=attach)
            )
            self._terminal_relay_tasks[terminal_id] = (token, task)
            self._background_tasks.add(task)

            def completed(done: asyncio.Task[None]) -> None:
                if self._terminal_relay_tasks.get(terminal_id) == (token, done):
                    self._terminal_relay_tasks.pop(terminal_id, None)
                self._on_background_upload_done(done)

            task.add_done_callback(completed)
            return {"terminalId": terminal_id, "connecting": True}

    def _schedule_background(self, awaitable: Any) -> None:
        task = asyncio.create_task(awaitable)
        self._background_tasks.add(task)
        task.add_done_callback(self._on_background_upload_done)

    async def _run_terminal_relay(
        self, terminal_id: str, token: str, *, attach: bool = False
    ) -> None:
        await self._terminal_relay.run(terminal_id, token, attach=attach)

    def _on_background_upload_done(self, task: asyncio.Task[Any]) -> None:
        self._background_tasks.discard(task)
        try:
            task.result()
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.exception("connector background task failed")

    def _get_http_client(self) -> httpx.AsyncClient | None:
        return self._http_client

    def _new_http_client(self, timeout: httpx.Timeout | float) -> httpx.AsyncClient:
        return self._egress.http_client(timeout)


def _is_auth_close(exc: ConnectionClosed) -> bool:
    reason = _close_reason(exc).lower()
    return (
        # 1008 can reject a short-lived access token, not the saved credential.
        # Reconnect refreshes access tokens; only explicit revocation is final.
        _close_code(exc) == 4001
        and "connector" in reason
        and any(marker in reason for marker in ("invalid", "revok", "delet", "credential"))
    )


def notification_requires_ingest(method: str) -> bool:
    return method in INGEST_ONLY_NOTIFICATION_METHODS


def _close_code(exc: ConnectionClosed) -> int | None:
    close = getattr(exc, "rcvd", None) or getattr(exc, "sent", None)
    code = getattr(close, "code", None)
    return code if isinstance(code, int) else None


def _close_reason(exc: ConnectionClosed) -> str:
    close = getattr(exc, "rcvd", None) or getattr(exc, "sent", None)
    reason = getattr(close, "reason", "")
    return reason if isinstance(reason, str) else ""


def main() -> None:
    asyncio.run(BackendRpcClient(ConnectorConfig.load()).run_forever())


def runtime_switch_directory(config: ConnectorConfig) -> Path:
    """Where the last accepted runtime switch per instance is kept."""

    state_path = Path(config.state_path or JsonSyncStateStore.default_path())
    return (
        state_path.expanduser().parent
        / "runtime-switch"
        / safe_file_stem(config.connector_id or "default")
    )
