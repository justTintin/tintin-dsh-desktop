"""Claude session cache helpers."""
