from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from enum import Enum

from openai_codex.generated.v2_all import (
    AgentMessageDeltaNotification,
    AgentMessageThreadItem,
    CollabAgentState,
    CollabAgentToolCallThreadItem,
    CommandExecutionOutputDeltaNotification,
    CommandExecutionThreadItem,
    ContentItem,
    ContextCompactionThreadItem,
    DynamicToolCallOutputContentItem,
    DynamicToolCallThreadItem,
    FileChangeOutputDeltaNotification,
    FileChangePatchUpdatedNotification,
    FileChangeThreadItem,
    FileUpdateChange,
    FunctionCallOutputResponseItem,
    FunctionCallResponseItem,
    InputImageContentItem,
    InputImageDynamicToolCallOutputContentItem,
    InputTextContentItem,
    InputTextDynamicToolCallOutputContentItem,
    ItemCompletedNotification,
    ItemStartedNotification,
    LocalImageUserInput,
    McpToolCallThreadItem,
    MentionUserInput,
    MessageResponseItem,
    OutputTextContentItem,
    PlanDeltaNotification,
    PlanThreadItem,
    RawResponseItemCompletedNotification,
    ReasoningSummaryPartAddedNotification,
    ReasoningSummaryTextDeltaNotification,
    ReasoningTextDeltaNotification,
    ReasoningThreadItem,
    ResponseItem,
    SubAgentActivityThreadItem,
    TextUserInput,
    Thread,
    ThreadItem,
    UserInput,
    UserMessageThreadItem,
    WebSearchThreadItem,
)

from connector.runtimes.codex.domain.input_requests import (
    CODEX_REQUEST_USER_INPUT_ASYNC,
    async_input_timeline_item_id,
    parse_async_input_reply,
)
from connector.runtimes.codex.sdk.events import CodexSdkEvent
from connector.runtimes.codex.timeline.agent_calls import (
    subagent_activity_arguments,
    subagent_activity_native_action,
)
from connector.runtimes.codex.timeline.identity import (
    next_turn_lane_position,
    turn_item_lane,
    uses_turn_position_identity,
)
from connector.runtimes.codex.timeline.projection import CodexTimelineProjection
from connector.runtimes.codex.timeline.web_search import web_search_values


def timeline_projection_from_sdk_event(
    event: CodexSdkEvent,
) -> CodexTimelineProjection | None:
    payload = event.payload
    if payload is None:
        return None
    if isinstance(payload, AgentMessageDeltaNotification):
        return CodexTimelineProjection(
            native_id=payload.item_id,
            raw_type="agentMessage",
            status="inProgress",
            role="assistant",
            turn_id=payload.turn_id,
            text=payload.delta,
        )
    if isinstance(payload, CommandExecutionOutputDeltaNotification):
        return CodexTimelineProjection(
            native_id=payload.item_id,
            raw_type="commandExecution",
            status="inProgress",
            turn_id=payload.turn_id,
            aggregated_output=payload.delta,
        )
    if isinstance(payload, FileChangeOutputDeltaNotification):
        return CodexTimelineProjection(
            native_id=payload.item_id,
            raw_type="fileChange",
            status="inProgress",
            turn_id=payload.turn_id,
            patch=payload.delta,
        )
    if isinstance(payload, FileChangePatchUpdatedNotification):
        return CodexTimelineProjection(
            native_id=payload.item_id,
            raw_type="fileChange",
            status="inProgress",
            turn_id=payload.turn_id,
            changes=tuple(
                file_update_change_mapping(change) for change in payload.changes
            ),
        )
    if isinstance(
        payload,
        ReasoningTextDeltaNotification | ReasoningSummaryTextDeltaNotification,
    ):
        return CodexTimelineProjection(
            native_id=payload.item_id,
            raw_type="reasoning",
            status="inProgress",
            role="system",
            turn_id=payload.turn_id,
            text=payload.delta,
        )
    if isinstance(payload, PlanDeltaNotification):
        return CodexTimelineProjection(
            native_id=payload.item_id,
            raw_type="systemMessage",
            status="inProgress",
            role="system",
            turn_id=payload.turn_id,
            message=payload.delta,
        )
    if isinstance(payload, ReasoningSummaryPartAddedNotification):
        return CodexTimelineProjection(
            native_id=payload.item_id,
            raw_type="reasoning",
            status="inProgress",
            role="system",
            turn_id=payload.turn_id,
        )
    if isinstance(payload, ItemStartedNotification):
        return timeline_projection_from_thread_item(
            item=payload.item,
            turn_id=payload.turn_id,
            event_status="inProgress",
        )
    if isinstance(payload, ItemCompletedNotification):
        return timeline_projection_from_thread_item(
            item=payload.item,
            turn_id=payload.turn_id,
            event_status="completed",
        )
    if isinstance(payload, RawResponseItemCompletedNotification):
        return timeline_projection_from_response_item(
            item=payload.item,
            turn_id=payload.turn_id,
            event_status="completed",
        )
    return None


def timeline_projections_from_sdk_thread(
    thread: Thread,
    limit: int | None,
) -> tuple[CodexTimelineProjection, ...]:
    projections: list[CodexTimelineProjection] = []
    for turn in thread.turns:
        next_position_by_lane: dict[str, int] = {}
        for item in turn.items:
            projection = timeline_projection_from_thread_item(
                item=item,
                turn_id=turn.id,
                event_status=None,
            )
            if projection is not None:
                if uses_turn_position_identity(
                    projection.raw_type, projection.effective_role()
                ):
                    lane = turn_item_lane(
                        projection.raw_type,
                        projection.effective_role(),
                    )
                    position = next_turn_lane_position(next_position_by_lane, lane)
                    projection = projection.with_turn_position(position)
                projections.append(projection)
    if limit is None:
        return tuple(projections)
    if limit <= 0:
        return ()
    return tuple(projections[-limit:])


def sdk_event_delta_text(event: CodexSdkEvent) -> str | None:
    payload = event.payload
    if isinstance(
        payload,
        AgentMessageDeltaNotification
        | CommandExecutionOutputDeltaNotification
        | FileChangeOutputDeltaNotification
        | ReasoningTextDeltaNotification
        | ReasoningSummaryTextDeltaNotification
        | PlanDeltaNotification,
    ):
        return payload.delta
    return None


def timeline_projection_from_thread_item(
    item: ThreadItem,
    turn_id: str | None,
    event_status: str | None,
) -> CodexTimelineProjection | None:
    root = item.root
    if isinstance(root, AgentMessageThreadItem):
        if root.questions:
            return CodexTimelineProjection(
                native_id=root.id,
                raw_type="function_call",
                platform_id=async_input_timeline_item_id(root.id),
                status=event_status,
                role="tool",
                turn_id=turn_id,
                name=CODEX_REQUEST_USER_INPUT_ASYNC,
                arguments={
                    "questions": [
                        {"title": question.title, "options": question.options or []}
                        for question in root.questions
                    ]
                },
                call_id=root.id,
            )
        return CodexTimelineProjection(
            native_id=root.id,
            raw_type="agentMessage",
            status=event_status,
            role="assistant",
            turn_id=turn_id,
            text=root.text,
        )
    if isinstance(root, UserMessageThreadItem):
        text = user_input_text(root.content)
        full_message_text = "\n".join(
            entry.root.text
            for entry in root.content
            if isinstance(entry.root, TextUserInput)
        )
        async_reply = parse_async_input_reply(full_message_text)
        return CodexTimelineProjection(
            native_id=root.id,
            raw_type="userMessage",
            status=event_status,
            role="user",
            turn_id=turn_id,
            text=async_reply.readable_text if async_reply is not None else text,
            attachments=user_input_attachments(root.content),
            client_message_id=root.client_id,
            async_reply_call_ids=(
                async_reply.call_ids if async_reply is not None else ()
            ),
            native_message_text=text if async_reply is not None else None,
        )
    if isinstance(root, ReasoningThreadItem):
        return CodexTimelineProjection(
            native_id=root.id,
            raw_type="reasoning",
            status=event_status,
            role="system",
            turn_id=turn_id,
            text=reasoning_text(root.content, root.summary),
        )
    if isinstance(root, CommandExecutionThreadItem):
        return CodexTimelineProjection(
            native_id=root.id,
            raw_type="commandExecution",
            status=enum_value(root.status) or event_status,
            role="tool",
            turn_id=turn_id,
            command=root.command,
            aggregated_output=root.aggregated_output,
            exit_code=root.exit_code,
        )
    if isinstance(root, McpToolCallThreadItem):
        return CodexTimelineProjection(
            native_id=root.id,
            raw_type="mcpToolCall",
            status=enum_value(root.status) or event_status,
            role="tool",
            turn_id=turn_id,
            server=root.server,
            name=root.tool,
            arguments=root.arguments,
            output=mcp_tool_call_result(root),
            message=mcp_tool_call_error_message(root),
        )
    if isinstance(root, DynamicToolCallThreadItem):
        return CodexTimelineProjection(
            native_id=root.id,
            raw_type="dynamicToolCall",
            status=enum_value(root.status) or event_status,
            role="tool",
            turn_id=turn_id,
            server=root.namespace,
            name=root.tool,
            arguments=root.arguments,
            output=dynamic_tool_call_output(root.content_items),
        )
    if isinstance(root, CollabAgentToolCallThreadItem):
        return CodexTimelineProjection(
            native_id=root.id,
            raw_type="collabAgentToolCall",
            status=enum_value(root.status) or event_status,
            role="tool",
            turn_id=turn_id,
            name=enum_value(root.tool) or "agent",
            arguments=collab_agent_tool_arguments(root),
            output=collab_agent_tool_output(root.agents_states),
        )
    if isinstance(root, SubAgentActivityThreadItem):
        return CodexTimelineProjection(
            native_id=root.id,
            raw_type="SubAgentActivityThreadItem",
            status=event_status,
            role="tool",
            turn_id=turn_id,
            name=subagent_activity_native_action(enum_value(root.kind)),
            arguments=subagent_activity_arguments(
                agent_path=root.agent_path,
                agent_thread_id=root.agent_thread_id,
            ),
        )
    if isinstance(root, WebSearchThreadItem):
        query, action = web_search_values(
            root.query,
            root.action.root.type if root.action is not None else None,
        )
        return CodexTimelineProjection(
            native_id=root.id,
            raw_type="webSearch",
            status=event_status,
            role="tool",
            turn_id=turn_id,
            message=query,
            arguments=action,
        )
    if isinstance(root, FileChangeThreadItem):
        return CodexTimelineProjection(
            native_id=root.id,
            raw_type="fileChange",
            status=enum_value(root.status) or event_status,
            turn_id=turn_id,
            changes=tuple(
                file_update_change_mapping(change) for change in root.changes
            ),
        )
    if isinstance(root, PlanThreadItem):
        return CodexTimelineProjection(
            native_id=root.id,
            raw_type="systemMessage",
            status=event_status,
            role="system",
            turn_id=turn_id,
            message=root.text,
        )
    if isinstance(root, ContextCompactionThreadItem):
        return CodexTimelineProjection(
            native_id=root.id,
            raw_type="contextCompaction",
            status=event_status,
            role="system",
            turn_id=turn_id,
        )
    return CodexTimelineProjection(
        native_id=None,
        raw_type=root.__class__.__name__,
        status=event_status,
        turn_id=turn_id,
    )


def timeline_projection_from_response_item(
    item: ResponseItem,
    turn_id: str | None,
    event_status: str | None,
) -> CodexTimelineProjection | None:
    root = item.root
    if isinstance(root, MessageResponseItem):
        raw_type = "agentMessage" if root.role == "assistant" else "userMessage"
        text = content_items_text(root.content)
        async_reply = (
            parse_async_input_reply(text)
            if root.role == "user" and text is not None
            else None
        )
        return CodexTimelineProjection(
            native_id=root.id,
            raw_type=raw_type,
            status=event_status,
            role=root.role,
            turn_id=turn_id,
            text=async_reply.readable_text if async_reply is not None else text,
            async_reply_call_ids=(
                async_reply.call_ids if async_reply is not None else ()
            ),
            native_message_text=text if async_reply is not None else None,
        )
    if isinstance(root, FunctionCallResponseItem):
        return CodexTimelineProjection(
            native_id=root.id or root.call_id,
            raw_type="function_call",
            platform_id=(
                async_input_timeline_item_id(root.call_id)
                if root.name == CODEX_REQUEST_USER_INPUT_ASYNC
                else None
            ),
            status=event_status,
            role="tool",
            turn_id=turn_id,
            name=root.name,
            arguments=root.arguments,
            call_id=root.call_id,
        )
    if isinstance(root, FunctionCallOutputResponseItem):
        return CodexTimelineProjection(
            native_id=root.id,
            raw_type="function_call_output",
            status=event_status,
            role="tool",
            turn_id=turn_id,
            call_id=root.call_id,
            output=root.output.root,
        )
    return CodexTimelineProjection(
        native_id=None,
        raw_type=root.__class__.__name__,
        status=event_status,
        turn_id=turn_id,
    )


def file_update_change_mapping(change: FileUpdateChange) -> dict[str, str]:
    kind = enum_value(change.kind) or "unknown"
    return {
        "kind": kind,
        "action": kind,
        "path": change.path,
        "diff": change.diff,
    }


def mcp_tool_call_result(item: McpToolCallThreadItem) -> object | None:
    if item.result is None:
        return None
    if item.result.structured_content is not None:
        return item.result.structured_content
    return list(item.result.content)


def mcp_tool_call_error_message(item: McpToolCallThreadItem) -> str | None:
    if item.error is None:
        return None
    return item.error.message


def dynamic_tool_call_output(
    content_items: Sequence[DynamicToolCallOutputContentItem] | None,
) -> str | None:
    if content_items is None:
        return None
    parts: list[str] = []
    for item in content_items:
        root = item.root
        if isinstance(root, InputTextDynamicToolCallOutputContentItem):
            parts.append(root.text)
        elif isinstance(root, InputImageDynamicToolCallOutputContentItem):
            parts.append(root.image_url)
    return "\n".join(parts) if parts else None


def collab_agent_tool_arguments(
    item: CollabAgentToolCallThreadItem,
) -> dict[str, object]:
    return {
        "senderThreadId": item.sender_thread_id,
        "receiverThreadIds": list(item.receiver_thread_ids),
        "prompt": item.prompt,
        "model": item.model,
        "reasoningEffort": enum_value(item.reasoning_effort),
    }


def collab_agent_tool_output(states: dict[str, CollabAgentState]) -> dict[str, object]:
    return {
        agent_id: {
            "status": enum_value(state.status),
            "message": state.message,
        }
        for agent_id, state in states.items()
    }


def user_input_text(items: Sequence[UserInput]) -> str | None:
    parts: list[str] = []
    for item in items:
        root = item.root
        if isinstance(root, TextUserInput):
            text = strip_attachment_note_suffix(root.text)
            if text:
                parts.append(text)
    return "\n".join(parts) if parts else None


def is_attachment_note_text(text: str) -> bool:
    lines = [line for line in text.splitlines() if line.strip()]
    return bool(lines) and all(
        line.startswith(("Attached file: ", "[Attached file: ")) for line in lines
    )


def strip_attachment_note_suffix(text: str) -> str | None:
    if is_attachment_note_text(text):
        return None
    cut = len(text)
    for marker in (
        "\n\nAttached file: ",
        "\n\n[Attached file: ",
        "Attached file: ",
        "[Attached file: ",
    ):
        index = text.find(marker)
        if index >= 0 and index < cut:
            cut = index
    stripped = text[:cut].strip()
    return stripped if stripped else None


def user_input_attachments(
    items: Sequence[UserInput],
) -> tuple[Mapping[str, object], ...]:
    attachments: list[Mapping[str, object]] = []
    seen: set[str] = set()
    for item in items:
        root = item.root
        if isinstance(root, TextUserInput):
            add_attachment_notes_from_text(
                attachments=attachments,
                seen=seen,
                text=root.text,
            )
        elif isinstance(root, MentionUserInput):
            add_user_input_attachment(
                attachments=attachments,
                seen=seen,
                name=root.name,
                path=root.path,
                media_type=None,
            )
        elif isinstance(root, LocalImageUserInput):
            add_user_input_attachment(
                attachments=attachments,
                seen=seen,
                name=None,
                path=root.path,
                media_type="image/*",
            )
    return tuple(attachments)


ATTACHMENT_NOTE_PATTERN = re.compile(
    r"\[Attached file: (?P<name>.+?) "
    r"\((?P<media_type>.*?)(?:, (?P<size>\d+) bytes)?\) "
    r"at (?P<path>.*?)\]"
)


def add_attachment_notes_from_text(
    attachments: list[Mapping[str, object]],
    seen: set[str],
    text: str,
) -> None:
    for match in ATTACHMENT_NOTE_PATTERN.finditer(text):
        size = int(match.group("size")) if match.group("size") is not None else None
        add_user_input_attachment(
            attachments=attachments,
            seen=seen,
            name=match.group("name"),
            path=match.group("path"),
            media_type=match.group("media_type"),
            size=size,
        )


def add_user_input_attachment(
    attachments: list[Mapping[str, object]],
    seen: set[str],
    name: str | None,
    path: str,
    media_type: str | None,
    size: int | None = None,
) -> None:
    file_id = file_id_from_codex_attachment_path(path)
    if file_id in seen:
        return
    seen.add(file_id)
    payload: dict[str, object] = {
        "fileId": file_id,
        "path": path,
    }
    if name is not None and name:
        payload["name"] = name
    elif path:
        payload["name"] = path.rsplit("/", maxsplit=1)[-1]
    if media_type is not None:
        payload["mediaType"] = media_type
    if size is not None:
        payload["size"] = size
    attachments.append(payload)


def file_id_from_codex_attachment_path(path: str) -> str:
    basename = path.rsplit("/", maxsplit=1)[-1]
    prefix = basename.split("-", maxsplit=1)[0]
    if prefix:
        return prefix
    return f"codex:{path}"


def reasoning_text(
    content: Sequence[str] | None,
    summary: Sequence[str] | None,
) -> str | None:
    parts: list[str] = []
    if content is not None:
        parts.extend(content)
    if summary is not None:
        parts.extend(summary)
    return "\n".join(parts) if parts else None


def content_items_text(items: Sequence[ContentItem]) -> str | None:
    parts: list[str] = []
    for item in items:
        root = item.root
        if isinstance(root, InputTextContentItem | OutputTextContentItem):
            parts.append(root.text)
        elif isinstance(root, InputImageContentItem):
            parts.append(root.image_url)
    return "\n".join(parts) if parts else None


def enum_value(value: Enum | str | None) -> str | None:
    if isinstance(value, Enum):
        return str(value.value)
    if isinstance(value, str) and value:
        return value
    return None
